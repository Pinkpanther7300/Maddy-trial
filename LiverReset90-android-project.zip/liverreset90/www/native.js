// Native bridge: runs only inside the Capacitor Android shell; harmless in a browser.
(function(){
const C=window.Capacitor;if(!C||!C.isNativePlatform||!C.isNativePlatform())return;
const P=n=>C.registerPlugin(n),Prefs=P('Preferences'),App=P('App'),SB=P('StatusBar'),Splash=P('SplashScreen'),LN=P('LocalNotifications'),Cam=P('Camera'),FS=P('Filesystem'),Share=P('Share');
const REM=[['water','💧 Drink water','10:00'],['meal','🍽 Log your meal','13:00'],['walk','🚶 Post-meal walk','14:00'],['weigh','⚖️ Weigh in / measure','08:00'],['sleep','😴 Wind down for sleep','22:00']];
window.nativeSave=()=>{Prefs.set({key:K,value:JSON.stringify(S)}).catch(()=>{})};
const dl=draw;draw=function(){dl();paint()};
async function boot(){
  try{if(!localStorage.getItem(K)){const r=await Prefs.get({key:K});if(r&&r.value){S=JSON.parse(r.value);localStorage.setItem(K,r.value)}}else nativeSave()}catch(e){}
  S.rem=S.rem||{};S.photos=S.photos||[];
  try{await SB.setBackgroundColor({color:'#0f9d76'});await SB.setStyle({style:'DARK'})}catch(e){}
  App.addListener('backButton',()=>{if(tab!=='home'){tab='home';draw();scrollTo(0,0)}else App.exitApp()});
  draw();try{Splash.hide()}catch(e){}
}
function paint(){const el=document.getElementById('nat');if(!el)return;S.rem=S.rem||{};S.photos=S.photos||[];
 el.innerHTML=`<div class="card"><h2>Reminders</h2><p class="m s">Set times to match today's shift — change them any time.</p>${REM.map(([k,n,t])=>{const r=S.rem[k]||{t,on:0};return `<div class="row"><span>${n}</span><span><input type="time" id="rt_${k}" value="${r.t}" style="width:auto"> <input type="checkbox" id="rc_${k}" ${r.on?'checked':''} style="width:auto" onchange="natRem('${k}')"></span></div>`}).join('')}<button class="o" onclick="natRem()">Save times</button></div>
 <div class="card"><h2>Private progress photos</h2><p class="m s">Stored only inside the app on this phone.</p><button onclick="natPhoto()">Add photo</button><div id="ph" class="g2"></div></div>
 <div class="card"><h2>Backup file</h2><button onclick="natExport('json')">Share backup (.json)</button><button class="o" onclick="natExport('csv')">Share data (.csv)</button></div>`;
 showPhotos()}
window.natRem=async k=>{try{const p=await LN.requestPermissions();if(p.display!=='granted'){alert('Notifications are blocked. Enable them in Android Settings → Apps → Liver Reset 90.');return}
 S.rem=S.rem||{};REM.forEach(([key,n,t],i)=>{const el=document.getElementById('rt_'+key);S.rem[key]={t:el.value||t,on:document.getElementById('rc_'+key).checked}});save();
 await LN.cancel({notifications:REM.map((_,i)=>({id:i+1}))});
 const ns=REM.map(([key,n],i)=>({key,n,i})).filter(x=>S.rem[x.key].on).map(x=>{const [h,m]=S.rem[x.key].t.split(':').map(Number);return{id:x.i+1,title:'Liver Reset 90',body:x.n.replace(/^\S+\s/,''),schedule:{on:{hour:h,minute:m},allowWhileIdle:true}}});
 if(ns.length)await LN.schedule({notifications:ns});if(!k)alert('Reminders saved.')}catch(e){alert('Could not set reminders: '+e.message)}};
window.natPhoto=async()=>{try{const r=await Cam.getPhoto({quality:70,resultType:'base64',source:'PROMPT',correctOrientation:true});const f='photo_'+Date.now()+'.jpg';await FS.writeFile({path:f,data:r.base64String,directory:'DATA'});S.photos.push({d:cur,f});save();showPhotos()}catch(e){}};
async function showPhotos(){const el=document.getElementById('ph');if(!el)return;el.innerHTML='';for(const [i,p] of S.photos.entries()){try{const r=await FS.readFile({path:p.f,directory:'DATA'});el.insertAdjacentHTML('beforeend',`<div><img src="data:image/jpeg;base64,${r.data}" style="width:100%;border-radius:12px"><div class="m s">${p.d} <button class="x" onclick="natDelPhoto(${i})">✕</button></div></div>`)}catch(e){}}}
window.natDelPhoto=async i=>{try{await FS.deleteFile({path:S.photos[i].f,directory:'DATA'})}catch(e){}S.photos.splice(i,1);save();showPhotos()};
window.natExport=async t=>{try{const b=$('bk');if(t==='json')b.value=JSON.stringify(S);else csv();const f=`LiverReset90-${td()}.${t}`;await FS.writeFile({path:f,data:b.value,directory:'CACHE',encoding:'utf8'});const u=await FS.getUri({path:f,directory:'CACHE'});await Share.share({title:f,url:u.uri})}catch(e){alert('Export failed: '+e.message)}};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
