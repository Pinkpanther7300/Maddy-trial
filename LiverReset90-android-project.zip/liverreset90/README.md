# Liver Reset 90 – Android (Capacitor)
Single-page web app (vanilla JS, no framework) wrapped with Capacitor. Not React/Next/React Native.
Data: localStorage mirrored to native Preferences (survives WebView storage clears). Native: reminders, camera/gallery, file share (backup/CSV), back button, status bar, splash.

## A. Build the APK in the cloud (no Android Studio)
1. Create a private GitHub repo, upload this folder's contents, push to `main`.
2. Actions tab → "Build APK" → Run workflow → download artifact `LiverReset90-v1.0.apk` (unzip once).
   Without secrets this is a debug-signed APK: installable, fine for personal use.

## B. Signed release (do once, keep the keystore safe — losing it blocks updates)
    keytool -genkeypair -v -keystore release.jks -alias liverreset -keyalg RSA -keysize 2048 -validity 10000
    base64 -w0 release.jks     # macOS: base64 -i release.jks
Repo → Settings → Secrets → Actions: KEYSTORE_B64, KEY_ALIAS (liverreset), KEYSTORE_PASSWORD. Re-run the workflow.

## C. Build locally instead (Node 20, JDK 21, Android Studio/SDK)
    npm install && npx cap add android && npx capacitor-assets generate --android
    # in android/app/src/main/AndroidManifest.xml: add android:screenOrientation="portrait" to <activity> and the POST_NOTIFICATIONS permission
    npx cap sync android && cd android && ./gradlew assembleDebug
APK: android/app/build/outputs/apk/debug/app-debug.apk (rename to LiverReset90-v1.0.apk)

## Install
Copy the APK to the phone → open it → allow "Install unknown apps" for your file manager/browser → Install.

## Update
Edit www/index.html, bump nothing else, rebuild with the SAME keystore, install over the old app (data is kept). For a new version number, edit versionName/versionCode in android/app/build.gradle after `cap add`.

## Backup / restore
Progress tab → "Share backup (.json)" → save to Drive/Files. Restore: open the file, copy its text, paste in Progress → Backup box → "Restore from JSON". Backup before uninstalling: uninstalling deletes app data.
